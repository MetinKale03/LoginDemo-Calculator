package com.example.logindemo;

import android.content.Intent;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;

public class WorkFragment extends Fragment {
    private Button button;
    TextView result;
    EditText StartTime, EndTime;
    Button Bereken;

    int ResultNum;
    int num1,num2;

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_work,container, false);
        button =(Button) view.findViewById(R.id.button);
        button.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent= new Intent(getActivity(), CalculatorActivity.class);
                intent.putExtra("some_key", ResultNum);
                startActivity(intent);
            }
        });


        result=(TextView) view.findViewById(R.id.txtUur);
        StartTime=(EditText) view.findViewById(R.id.StartTime);
        EndTime=(EditText) view.findViewById(R.id.EndTime);
        Bereken=(Button) view.findViewById(R.id.btnCalc);


        Bereken.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                num1=Integer.parseInt(StartTime.getText().toString());
                num2=Integer.parseInt(EndTime.getText().toString());
                if(num1>24||num2>24){
                    result.setText("max waarde is 24");
                }
                else if(num2>num1){

                    ResultNum=num2-num1;
                    result.setText(String.valueOf(ResultNum)+" uur");
                }
                else if(num2<num1){
                    result.setText("Eindwaarde kan niet kleiner zijn dan startwaarde!");
                }
                else if(num2==num1){
                    result.setText("0 uur");
                }

            }
        });
        return view;
    }
}
